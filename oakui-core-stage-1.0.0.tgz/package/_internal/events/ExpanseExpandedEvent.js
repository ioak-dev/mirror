import { Subject } from 'rxjs';
export const expanseExpandedSubject = new Subject();
//# sourceMappingURL=ExpanseExpandedEvent.js.map