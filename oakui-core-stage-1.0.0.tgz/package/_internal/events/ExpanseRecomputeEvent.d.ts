import { Subject } from 'rxjs';
export declare const expanseRecomputeSubject: Subject<ExpanseRecomputeType>;
interface ExpanseRecomputeType {
    name?: string | null;
    groupName?: string | null;
}
export {};
//# sourceMappingURL=ExpanseRecomputeEvent.d.ts.map