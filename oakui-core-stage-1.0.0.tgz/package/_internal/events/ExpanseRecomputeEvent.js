import { Subject } from 'rxjs';
export const expanseRecomputeSubject = new Subject();
//# sourceMappingURL=ExpanseRecomputeEvent.js.map