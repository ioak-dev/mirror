import { Subject } from 'rxjs';
export declare const expanseExpandedSubject: Subject<ExpanseExpandedType>;
interface ExpanseExpandedType {
    elementId: string;
    groupName?: string | null;
}
export {};
//# sourceMappingURL=ExpanseExpandedEvent.d.ts.map