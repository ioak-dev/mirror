export declare const oakInternalPopupTextInputActionSizeStyles: import("lit-element").CSSResult;
//# sourceMappingURL=size-styles.d.ts.map