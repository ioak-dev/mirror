export declare const oakInternalPopupInputActionBorderStyles: import("lit-element").CSSResult;
//# sourceMappingURL=border-styles.d.ts.map