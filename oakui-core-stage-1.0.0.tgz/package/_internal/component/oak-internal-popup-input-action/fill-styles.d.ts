export declare const oakInternalPopupInputActionFillStyles: import("lit-element").CSSResult;
//# sourceMappingURL=fill-styles.d.ts.map