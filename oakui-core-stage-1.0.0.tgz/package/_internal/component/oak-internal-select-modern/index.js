var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { formControlRegisterSubject } from '../../events/FormControlRegisterEvent';
import { formControlValidatedSubject } from '../../events/FormControlValidatedEvent';
import { formControlValidateSubject } from '../../events/FormControlValidateEvent';
import { globalStyles } from '../../styles/global-styles';
import '../oak-internal-popup';
import '../oak-internal-popup-text-input-action';
import '../oak-internal-popup-input-action';
import '../../../component/oak-label';
import { oakInternalSelectModernStyles } from './index-styles';
import { isEmptyOrSpaces, toString } from '../../utils/StringUtils';
import { RequiredValidator } from '../../validator/RequiredValidator';
import { oakInternalSelectModernSizeStyles } from './size-styles';
import { oakInternalSelectModernFillStyles } from './fill-styles';
import { SELECT_CHANGE_EVENT, SELECT_INPUT_EVENT, SELECT_ACTION_ITEM_EVENT, } from '../../../event/OakSelectEvent';
let elementIdCounter = 0;
const customElementName = 'oak-internal-select-modern';
/**
 * Select drop down (native) form element.
 *
 */
let OakInternalSelectModern = class OakInternalSelectModern extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.rootElementId = `${this.elementId}-root`;
        this.liElementId = `${this.elementId}-popup-li`;
        this.ulElementId = `${this.elementId}-popup-ul`;
        this._isActivated = false;
        this._currentIndex = 0;
        this._searchCriteria = '';
        this.label = null;
        this.placeholder = '';
        this.multiple = false;
        this.tooltip = '';
        this.name = this.elementId;
        this.disabled = false;
        this.fill = false;
        this.autocomplete = false;
        this.size = 'small';
        this.shape = 'rectangle';
        this.color = 'container';
        this.popupColor = 'auto';
        /**
         * 	If true, the text will have a bottom margin.
         */
        this.gutterBottom = false;
        this.positioningStrategy = 'absolute';
        /**
         * Validators
         *
         */
        /**
         * @private
         */
        this._errors = [];
        this._subscriptions = [];
        this.handleChange = (index) => {
            var _a, _b;
            if (this._isActivated) {
                const searchResults = this.search();
                this.propagateCustomEvent(SELECT_CHANGE_EVENT, (_a = searchResults[index]) === null || _a === void 0 ? void 0 : _a.id);
                this.propagateCustomEvent(SELECT_INPUT_EVENT, (_b = searchResults[index]) === null || _b === void 0 ? void 0 : _b.id);
                if (!this.multiple) {
                    this._deactivate();
                }
            }
        };
        this.handleActionItemChange = (actionItem) => {
            this.propagateCustomEvent(SELECT_ACTION_ITEM_EVENT, actionItem, {
                criteria: this._searchCriteria,
                action: actionItem,
            });
            this._deactivate();
        };
        this.keydownEventHandler = (event) => {
            switch (event.key) {
                case 'ArrowDown':
                    event.preventDefault();
                    this.navigateDown();
                    break;
                case 'ArrowUp':
                    event.preventDefault();
                    this.navigateUp();
                    break;
                case 'Enter':
                    if (this._isActivated) {
                        event.preventDefault();
                        this.handleChange(this._currentIndex);
                    }
                    break;
                case 'Tab':
                    if (this._isActivated) {
                        event.preventDefault();
                        this._deactivate();
                    }
                    break;
                default:
                    break;
            }
        };
        this.navigateUp = () => {
            var _a;
            if (this._currentIndex > 0) {
                const elRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(`${this.liElementId}-${this._currentIndex - 1}`);
                if (elRef && !this.isScrolledIntoView(elRef)) {
                    elRef.scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest',
                        inline: 'start',
                    });
                }
                this._currentIndex = this._currentIndex - 1;
            }
            else {
                this._currentIndex = 0;
            }
        };
        this.isScrolledIntoView = (el, invertDirection = false) => {
            var _a;
            const rect = el.getBoundingClientRect();
            const elemTop = rect.top;
            const elemBottom = rect.bottom;
            const containerEl = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(this.ulElementId);
            if (!containerEl) {
                return true;
            }
            // Only completely visible elements return true:
            let isVisible = true;
            if (invertDirection) {
                isVisible =
                    elemTop >= 0 &&
                        elemBottom <=
                            containerEl.getBoundingClientRect().height +
                                containerEl.getBoundingClientRect().top;
            }
            else {
                isVisible =
                    elemTop >= 0 &&
                        elemTop >=
                            containerEl.getBoundingClientRect().height +
                                containerEl.getBoundingClientRect().top;
            }
            // Partially visible elements return true:
            //isVisible = elemTop < containerEl.getBoundingClientRect().height && elemBottom >= 0;
            return isVisible;
        };
        this._activate = () => {
            var _a;
            this._isActivated = true;
            const chosenIndex = this._searchResults().findIndex((item) => item.id === this.value);
            this._currentIndex = chosenIndex < 0 ? 0 : chosenIndex;
            // const docRef = this.shadowRoot?.getElementById(this.elementId);
            const rootElRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(this.rootElementId);
            console.log('*********', 'rootElRef', rootElRef);
            // if (docRef) {
            //   docRef.addEventListener('keydown', this.keydownEventHandler);
            // }
            if (rootElRef) {
                rootElRef.addEventListener('keydown', this.keydownEventHandler);
            }
        };
        this._deactivate = () => {
            var _a;
            this._isActivated = false;
            this._searchCriteria = '';
            const docRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(this.elementId);
            if (docRef) {
                docRef.removeEventListener('keydown', this.keydownEventHandler);
            }
        };
        this._toggle = () => {
            if (this._isActivated) {
                this._deactivate();
            }
            else {
                this._activate();
            }
        };
        this.handleKeydown = (event) => {
            if (this._isActivated) {
                this.keydownEventHandler(event.detail.value);
            }
        };
        this.search = () => {
            return this._searchResults();
            // if (isEmptyOrSpaces(this._searchCriteria)) {
            //   return this.options;
            // }
            // return this.options.filter((option: any) =>
            //   toString(option).includes(this._searchCriteria)
            // );
        };
        this._searchResults = () => {
            var _a;
            if (isEmptyOrSpaces(this._searchCriteria)) {
                return this.options
                    ? this._getOptions(this.options)
                    : this._getOptionsFromKeyValue(this.optionsAsKeyValue);
            }
            else {
                if (this.options) {
                    return this._getOptions(this.options.filter((option) => toString(option).includes(this._searchCriteria)));
                }
                return this._getOptionsFromKeyValue((_a = this.optionsAsKeyValue) === null || _a === void 0 ? void 0 : _a.filter((option) => toString(option.value).includes(this._searchCriteria)));
            }
        };
        this._getOptions = (_options) => {
            if (_options) {
                return _options.map((item) => {
                    return {
                        id: item,
                        value: item,
                    };
                });
            }
            return [];
        };
        this._getOptionsFromKeyValue = (_options) => {
            if (_options) {
                return _options.map((item) => {
                    return {
                        id: item.id,
                        value: item.value,
                    };
                });
            }
            return [];
        };
        this.validate = () => {
            this._errors = [];
            this._errors = this._errors.concat(RequiredValidator(this.value));
            formControlValidatedSubject.next({
                formGroupName: this.formGroupName || '',
                formControlName: this.name,
                isValid: this._errors.length === 0,
                formControlValue: this.value,
                errors: this._errors,
            });
        };
        this.getClassMap = (baseClass, index) => {
            switch (baseClass) {
                case 'action':
                case 'value':
                case 'placeholder':
                case 'li-indicator':
                case 'li-text':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'ul':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                        activated: this._isActivated,
                    };
                case 'li':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                        [`${customElementName}__${baseClass}--active`]: this._currentIndex === index,
                    };
                case 'li-action-item':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'margin':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                        'oak-gutter-bottom': this.gutterBottom,
                    };
                case 'search-filter':
                case 'popup':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                        [`${customElementName}__${baseClass}--fill-${this.color}`]: this.popupColor === 'auto',
                        [`${customElementName}__${baseClass}--fill-${this.popupColor}`]: this.popupColor !== 'auto',
                    };
                case 'input':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                        [`${customElementName}__${baseClass}--size-${this.size}`]: true,
                        [`oak-shape-${this.shape}`]: this.shape !== 'underline',
                        [`oak-fill-${this.color}`]: true,
                        [`oak-fill-${this.color}--hover`]: true,
                    };
                default:
                    return {};
            }
        };
        this.propagateCustomEvent = (eventName, value, rest = {}) => {
            let _value = [];
            if (this.multiple) {
                if (this.value && Array.isArray(this.value)) {
                    if (this.value.includes(value)) {
                        _value = this.value.filter((item) => item !== value);
                    }
                    else {
                        _value = [...this.value, value];
                    }
                }
                else {
                    _value = [value];
                }
            }
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail: Object.assign({ id: this.elementId, name: this.name, value: this.multiple ? _value : value }, rest),
            }));
        };
        this._handleSearchCriteriaChange = (event) => {
            this._searchCriteria = event.detail.value;
        };
    }
    connectedCallback() {
        super.connectedCallback();
        this._registerEvents();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this._unregisterEvents();
        this._subscriptions.forEach((item) => item.unsubscribe());
    }
    _registerEvents() {
        if (this.formGroupName) {
            formControlRegisterSubject.next({
                formControlName: this.name,
                formGroupName: this.formGroupName,
            });
            this._subscriptions.push(formControlValidateSubject
                .asObservable()
                .subscribe((message) => {
                if (message.formGroupName === this.formGroupName) {
                    this.validate();
                }
            }));
        }
    }
    _unregisterEvents() {
        //
    }
    navigateDown() {
        var _a;
        if (this._currentIndex < this.search().length - 1) {
            const elRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(`${this.liElementId}-${this._currentIndex + 1}`);
            if (elRef && !this.isScrolledIntoView(elRef, true)) {
                elRef.scrollIntoView({
                    behavior: 'smooth',
                    block: 'nearest',
                    inline: 'start',
                });
            }
            this._currentIndex = this._currentIndex + 1;
        }
        else {
            this._currentIndex = 0;
        }
    }
    // private handleSearchCriteriaChange = (event: any) => {
    //   this._searchCriteria = event.detail.value;
    // };
    static get styles() {
        return [
            ...globalStyles,
            oakInternalSelectModernStyles,
            oakInternalSelectModernSizeStyles,
            oakInternalSelectModernFillStyles,
        ];
    }
    _getValue() {
        if (this.multiple && (!this.value || !Array.isArray(this.value))) {
            return [];
        }
        return this.value;
    }
    render() {
        var _a, _b, _c;
        const labelId = `${this.elementId}-label`;
        return html `
      <oak-label
        .label=${this.label}
        id=${labelId}
        elementFor=${this.elementId}
        ?noMargin=${this.shape === 'underline'}
      ></oak-label>
      <oak-internal-popup
        .id=${this.rootElementId}
        .value=${this.value}
        .placeholder=${this.placeholder}
        .label=${this.label}
        .errors=${this._errors}
        @popup-activate=${this._activate}
        @popup-deactivate=${this._deactivate}
        @popup-key-pressed=${this.handleKeydown}
        ?isActivated=${this._isActivated}
        .size=${this.size}
        .positioningStrategy=${this.positioningStrategy}
      >
        <div slot="action">
          ${this.autocomplete
            ? html `<oak-internal-popup-text-input-action
                @toggle=${this._toggle}
                .value=${this._getValue()}
                .options=${this.options}
                .optionsAsKeyValue=${this.optionsAsKeyValue}
                ?multiple=${this.multiple}
                .searchCriteria=${this._searchCriteria}
                ?isActivated=${this._isActivated}
                ?fill=${this.fill}
                .size=${this.size}
                .shape=${this.shape}
                .color=${this.color}
                @search-criteria-change=${this._handleSearchCriteriaChange}
              ></oak-internal-popup-text-input-action>`
            : html ` <oak-internal-popup-input-action
                @toggle=${this._toggle}
                .value=${this._getValue()}
                .options=${this.options}
                .optionsAsKeyValue=${this.optionsAsKeyValue}
                ?fill=${this.fill}
                ?multiple=${this.multiple}
                .size=${this.size}
                .shape=${this.shape}
                .color=${this.color}
              ></oak-internal-popup-input-action>`}
        </div>
        <div
          slot="popup"
          class=${classMap(this.getClassMap('popup'))}
          id=${this.elementId}
        >
          <ul
            role="listbox"
            id=${this.ulElementId}
            class=${classMap(this.getClassMap('ul'))}
          >
            ${(_a = this.actionItems) === null || _a === void 0 ? void 0 : _a.map((item) => html `<li
                role="option"
                class=${classMap(this.getClassMap('li-action-item'))}
                @click=${() => this.handleActionItemChange(item)}
              >
                ${item}
              </li>`)}
            ${!this._searchResults() || this._searchResults().length === 0
            ? html `${(_b = this.actionItemsWhenNoResults) === null || _b === void 0 ? void 0 : _b.map((item) => html `<li
                    role="option"
                    class=${classMap(this.getClassMap('li-action-item'))}
                    @click=${() => this.handleActionItemChange(item)}
                  >
                    ${item}
                  </li>`)}`
            : html ``}
            ${(_c = this._searchResults()) === null || _c === void 0 ? void 0 : _c.map((item, index) => {
            var _a;
            return html `<li
                  id=${`${this.liElementId}-${index}`}
                  role="option"
                  class=${classMap(this.getClassMap('li', index))}
                  @click=${() => this.handleChange(index)}
                >
                  <div class=${classMap(this.getClassMap('li-indicator'))}>
                    ${(this.multiple && ((_a = this.value) === null || _a === void 0 ? void 0 : _a.includes(item.id))) ||
                (!this.multiple && this.value === item.id)
                ? html `<svg
                          height="16"
                          viewBox="0 0 16 16"
                          version="1.1"
                          width="16"
                          aria-hidden="true"
                        >
                          <path
                            fill-rule="evenodd"
                            d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"
                          ></path>
                        </svg>`
                : html ``}
                  </div>
                  <div class=${classMap(this.getClassMap('li-text'))}>
                    ${item.value}
                  </div>
                </li>`;
        })}
            ${this._searchResults().length === 0
            ? html ` <li>No results found</li>`
            : html ``}
          </ul>
        </div>
      </oak-internal-popup>
      <oak-internal-form-tooltip
        .tooltip=${this.tooltip}
      ></oak-internal-form-tooltip>
      <oak-internal-form-error
        .errors=${this._errors}
      ></oak-internal-form-error>
      <div class=${classMap(this.getClassMap('margin'))}></div>
    `;
    }
};
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "_isActivated", void 0);
__decorate([
    property({ type: Number })
], OakInternalSelectModern.prototype, "_currentIndex", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "_searchCriteria", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "formGroupName", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "label", void 0);
__decorate([
    property()
], OakInternalSelectModern.prototype, "value", void 0);
__decorate([
    property({ type: Array })
], OakInternalSelectModern.prototype, "actionItems", void 0);
__decorate([
    property({ type: Array })
], OakInternalSelectModern.prototype, "actionItemsWhenNoResults", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "placeholder", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "multiple", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "tooltip", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "name", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "fill", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Array })
], OakInternalSelectModern.prototype, "options", void 0);
__decorate([
    property({ type: Array })
], OakInternalSelectModern.prototype, "optionsAsKeyValue", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "size", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "shape", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "color", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "popupColor", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalSelectModern.prototype, "gutterBottom", void 0);
__decorate([
    property({ type: String })
], OakInternalSelectModern.prototype, "positioningStrategy", void 0);
__decorate([
    property({ type: Array })
], OakInternalSelectModern.prototype, "_errors", void 0);
OakInternalSelectModern = __decorate([
    customElement(customElementName)
], OakInternalSelectModern);
export { OakInternalSelectModern };
//# sourceMappingURL=index.js.map