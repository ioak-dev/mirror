import { LitElement } from 'lit-element';
import '../oak-internal-popup';
import '../oak-internal-popup-text-input-action';
import '../oak-internal-popup-input-action';
import '../../../component/oak-label';
/**
 * Select drop down (native) form element.
 *
 */
export declare class OakInternalSelectModern extends LitElement {
    private elementId;
    private rootElementId;
    private liElementId;
    private ulElementId;
    private _isActivated;
    private _currentIndex;
    private _searchCriteria;
    formGroupName?: string;
    label?: string | null | undefined;
    value?: any;
    actionItems?: string[];
    actionItemsWhenNoResults?: string[];
    placeholder?: string;
    multiple?: boolean;
    tooltip?: string;
    name: string;
    disabled: boolean;
    fill?: boolean;
    autocomplete?: boolean | undefined;
    options?: any[] | null;
    optionsAsKeyValue?: {
        id: string | number;
        value: string | number;
    }[] | null;
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    shape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf' | 'underline';
    color?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'info' | 'invert' | 'danger' | 'warning' | 'success' | 'none';
    popupColor?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'info' | 'invert' | 'danger' | 'warning' | 'success' | 'auto';
    /**
     * 	If true, the text will have a bottom margin.
     */
    gutterBottom?: boolean;
    positioningStrategy?: 'absolute' | 'fixed';
    /**
     * Validators
     *
     */
    /**
     * @private
     */
    private _errors;
    private _subscriptions;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    private _registerEvents;
    private _unregisterEvents;
    private handleChange;
    private handleActionItemChange;
    private keydownEventHandler;
    private navigateDown;
    private navigateUp;
    private isScrolledIntoView;
    private _activate;
    private _deactivate;
    private _toggle;
    private handleKeydown;
    private search;
    private _searchResults;
    private _getOptions;
    private _getOptionsFromKeyValue;
    private validate;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    private propagateCustomEvent;
    private _handleSearchCriteriaChange;
    private _getValue;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map