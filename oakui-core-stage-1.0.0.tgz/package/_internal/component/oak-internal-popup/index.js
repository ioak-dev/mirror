var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { fromEvent } from 'rxjs';
import { map } from 'rxjs/operators';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../styles/global-styles';
import '../oak-internal-form-tooltip';
import '../oak-internal-form-error';
import '../oak-internal-popup-input-action';
import '../oak-internal-popup-text-input-action';
import '../../../component/oak-input';
import '../../../component/oak-button';
import { oakInternalPopupStyles } from './index-styles';
import { POPUP_DEACTIVATE, POPUP_KEY_PRESSED, } from '../../../event/OakPopupEvent';
import { createPopper } from '@popperjs/core';
import { containerScrolledSubject } from '../../events/ContainerScrolledEvent';
let elementIdCounter = 0;
const customElementName = 'oak-internal-popup';
/**
 * Select drop down (native) form element.
 *
 */
let OakSelect = class OakSelect extends LitElement {
    /**
     * Validators
     *
     */
    /**
     * @private
     */
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.actionElementId = `${this.elementId}-action`;
        this.popupElementId = `${this.elementId}-popup`;
        this.isActivated = false;
        this.parentElementIds = [];
        this.placeholder = '';
        this.multiple = false;
        this.tooltip = '';
        this.name = this.elementId;
        this.disabled = false;
        this.options = [];
        this.errors = [];
        this.scrollableContainers = [];
        this.size = 'small';
        this.shape = 'rectangle';
        this.fill = 'surface';
        this.type = 'input';
        this.placement = 'bottom-start';
        this.fallbackPlacements = ['top-start'];
        this.positioningStrategy = 'absolute';
        this._popperInstance = null;
        this._subscriptions = [];
        this.clickEventHandler = (event) => {
            if (this.isActivated) {
                const idList = [];
                Object.values(event.composedPath()).forEach((item) => {
                    try {
                        if (item &&
                            !(item instanceof ShadowRoot) &&
                            !(item instanceof Window) &&
                            !(item instanceof Document) &&
                            item.hasAttribute('id')) {
                            idList.push(item.getAttribute('id'));
                        }
                    }
                    catch (e) {
                        console.log('** exception inclickEventHandler');
                    }
                });
                if (![this.actionElementId, this.popupElementId].some((item) => idList.indexOf(item) !== -1)) {
                    this._deactivate();
                }
            }
        };
        this.keydownEventHandler = (event) => {
            this.propagateCustomEvent(POPUP_KEY_PRESSED, event);
        };
        this._deactivate = () => {
            var _a;
            this.propagateCustomEvent(POPUP_DEACTIVATE);
            const docRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(this.elementId);
            if (docRef) {
                docRef.removeEventListener('keydown', this.keydownEventHandler);
            }
        };
        this.getClassMap = (baseClass) => {
            switch (baseClass) {
                case 'base':
                    return {
                        [customElementName]: true,
                    };
                case 'action':
                    return {
                        [`${customElementName}--${baseClass}`]: true,
                    };
                case 'value':
                    return {
                        [`${customElementName}--${baseClass}`]: true,
                    };
                case 'placeholder':
                    return {
                        [`${customElementName}--${baseClass}`]: true,
                    };
                case 'popup':
                    return {
                        [`${customElementName}--${baseClass}`]: true,
                        [`oak-fill-${this.fill}`]: true,
                        activated: this.isActivated,
                    };
                default:
                    return {};
            }
        };
        this.propagateCustomEvent = (eventName, value) => {
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail: {
                    id: this.elementId,
                    name: this.name,
                    value: value || null,
                },
            }));
        };
    }
    connectedCallback() {
        super.connectedCallback();
        this._registerEvents();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this._unregisterEvents();
        this._subscriptions.forEach((item) => item.unsubscribe());
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        setTimeout(() => this._mountPopper());
    }
    shouldUpdate(_changedProperties) {
        _changedProperties.forEach((_, propName) => {
            if (propName === 'isActivated' &&
                this.isActivated &&
                this._popperInstance) {
                this._popperInstance.forceUpdate();
            }
        });
        return true;
    }
    _mountPopper() {
        var _a, _b;
        const trigger = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(`${this.actionElementId}`);
        const popup = (_b = this.shadowRoot) === null || _b === void 0 ? void 0 : _b.getElementById(`${this.popupElementId}`);
        if (trigger && popup) {
            this._popperInstance = createPopper(trigger, popup, {
                placement: this.placement,
                strategy: this.positioningStrategy,
                modifiers: [
                    {
                        name: 'flip',
                        options: {
                            fallbackPlacements: this.fallbackPlacements,
                        },
                    },
                ],
            });
        }
    }
    _registerEvents() {
        this._subscriptions.push(containerScrolledSubject.asObservable().subscribe(() => {
            if (this._popperInstance) {
                this._popperInstance.forceUpdate();
            }
        }));
        fromEvent(document, 'click')
            .pipe(map((event) => event))
            .subscribe((event) => this.clickEventHandler(event));
        fromEvent(window, 'keydown')
            .pipe(map((event) => event))
            .subscribe((event) => {
            if (['Escape'].includes(event.key)) {
                this._deactivate();
            }
        });
    }
    _unregisterEvents() {
        // window.removeEventListener('resize', this.adjustPositioning);
        // window.removeEventListener('scroll', this.adjustPositioning);
    }
    static get styles() {
        return [...globalStyles, oakInternalPopupStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <div
          class=${classMap(this.getClassMap('action'))}
          id=${this.actionElementId}
        >
          <slot name="action"></slot>
        </div>
        <div
          class=${classMap(this.getClassMap('popup'))}
          id=${this.popupElementId}
        >
          <slot name="popup"></slot>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "isActivated", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "parentElementIds", void 0);
__decorate([
    property()
], OakSelect.prototype, "value", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "placeholder", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "multiple", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "tooltip", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "name", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "disabled", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "options", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "optionsAsKeyValue", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "errors", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "scrollableContainers", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "size", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "shape", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "fill", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "type", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "placement", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "fallbackPlacements", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "positioningStrategy", void 0);
OakSelect = __decorate([
    customElement(customElementName)
], OakSelect);
export { OakSelect };
//# sourceMappingURL=index.js.map