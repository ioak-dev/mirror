import { LitElement } from 'lit-element';
import '../../../component/oak-label';
import '../oak-internal-form-tooltip';
import '../oak-internal-form-error';
/**
 * Select drop down (native) form element.
 *
 */
export declare class OakInternalSelectNative extends LitElement {
    private elementId;
    formGroupName?: string;
    label?: string | null | undefined;
    value?: string | number | null;
    placeholder?: string;
    multiple?: boolean;
    fill?: boolean;
    tooltip?: string;
    name: string;
    disabled: boolean;
    options?: any[] | null;
    optionsAsKeyValue?: {
        id: string | number;
        value: string | number;
    }[] | null;
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    shape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf' | 'underline';
    color?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'info' | 'invert' | 'danger' | 'warning' | 'success' | 'none';
    /**
     * 	If true, the text will have a bottom margin.
     */
    gutterBottom?: boolean;
    /**
     * Validators
     *
     */
    /**
     * @private
     */
    private _errors;
    private _subscriptions;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    private init;
    private validate;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    private handleInput;
    private handleChange;
    private propagateEvent;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map