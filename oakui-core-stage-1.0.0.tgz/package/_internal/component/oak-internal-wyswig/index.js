var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { Quill } from 'quill';
import { formControlRegisterSubject } from '../../events/FormControlRegisterEvent';
import { formControlValidatedSubject } from '../../events/FormControlValidatedEvent';
import { formControlValidateSubject } from '../../events/FormControlValidateEvent';
import { globalStyles } from '../../styles/global-styles';
import '../../component/oak-internal-form-tooltip';
import '../../component/oak-internal-form-error';
import { oakInputStyles } from './index-styles';
import { UserDefinedValidator } from '../../validator/UserDefinedValidator';
import { oakInputSizeStyles } from './size-styles';
import { oakInputBorderStyles } from './border-styles';
import { oakInputFillStyles } from './fill-styles';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
let elementIdCounter = 0;
/**
 * Text box form element.
 *
 */
const customElementName = 'oak-internal-wyswig';
let OakInternalWyswig = class OakInternalWyswig extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.label = null;
        this.placeholder = '';
        this.name = this.elementId;
        this.disabled = false;
        this.size = 'small';
        this.shape = 'rectangle';
        this.color = 'container';
        this.fill = false;
        /**
         * 	If true, the text will have a bottom margin.
         */
        this.gutterBottom = false;
        /**
         * @private
         */
        this._errors = [];
    }
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    init() {
        if (this.formGroupName) {
            formControlRegisterSubject.next({
                formControlName: this.name,
                formGroupName: this.formGroupName,
            });
            formControlValidateSubject
                .asObservable()
                .subscribe((message) => {
                if (message.formGroupName === this.formGroupName) {
                    this.validate();
                }
            });
        }
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        new Quill(`#${this.elementId}`, {
            modules: {
                toolbar: false,
            },
            theme: 'snow',
        });
    }
    validate() {
        this._errors = [];
        if (this.validatorFunction) {
            this._errors = this._errors.concat(UserDefinedValidator(this.validatorFunction, this.value, this.name, this.formGroupName));
        }
        formControlValidatedSubject.next({
            formGroupName: this.formGroupName || '',
            formControlName: this.name,
            isValid: this._errors.length === 0,
            formControlValue: this.value,
            errors: this._errors,
        });
    }
    // private handleInput = (event: any) => {
    //   this.propagateEvent(INPUT_INPUT_EVENT, event);
    // };
    // private handleChange = (event: any) => {
    //   this.propagateEvent(INPUT_CHANGE_EVENT, event);
    // };
    // private handleKeydown = (event: any) => {
    //   if (event.key === 'Enter' && !event.shiftKey) {
    //     this.handleSubmit(event);
    //   }
    // };
    // private handleFocus = (event: any) => {
    //   this.propagateEvent(INPUT_FOCUS_EVENT, event);
    // };
    // private handleSubmit = (event: any) => {
    //   if (this.formGroupName) {
    //     formControlSubmitSubject.next({
    //       formGroupName: this.formGroupName,
    //     });
    //   }
    //   this.propagateEvent(INPUT_SUBMIT_EVENT, event);
    // };
    // private propagateEvent = (eventName: string, event: any, value?: any) => {
    //   this.value = event.srcElement.value;
    //   this.dispatchEvent(
    //     new CustomEvent(eventName, {
    //       bubbles: true,
    //       composed: true,
    //       detail: {
    //         id: event.srcElement.id,
    //         name: event.srcElement.name,
    //         value: value || event.srcElement.value,
    //       },
    //     })
    //   );
    // };
    // private get inputEl(): HTMLInputElement {
    //   return this.shadowRoot!.getElementById(this.elementId)! as HTMLInputElement;
    // }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                    'oak-gutter-bottom': this.gutterBottom,
                };
            case 'input':
            case 'textarea':
                return {
                    [`${customElementName}-${baseClass}`]: true,
                    [`${customElementName}--size-${this.size}`]: true,
                    [`${customElementName}--color-${this.color}`]: true,
                    [`${customElementName}--fill`]: this.fill,
                    [`${customElementName}--fill-color-${this.color}`]: this.fill,
                    [`${customElementName}--underline`]: this.shape === 'underline',
                    [`${customElementName}--no-underline`]: this.shape !== 'underline',
                    [`oak-shape-${this.shape}`]: this.shape !== 'underline',
                    'validation-failure': this._errors.length > 0,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [
            ...globalStyles,
            oakInputStyles,
            oakInputSizeStyles,
            oakInputBorderStyles,
            oakInputFillStyles,
        ];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))}>
        WYSWIG EDITOR
        <div id=${this.elementId}></div>
        <oak-internal-form-error
          .errors=${this._errors}
        ></oak-internal-form-error>
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "formGroupName", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "label", void 0);
__decorate([
    property()
], OakInternalWyswig.prototype, "value", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "name", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalWyswig.prototype, "disabled", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "size", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "shape", void 0);
__decorate([
    property({ type: String })
], OakInternalWyswig.prototype, "color", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalWyswig.prototype, "fill", void 0);
__decorate([
    property({ type: Boolean })
], OakInternalWyswig.prototype, "gutterBottom", void 0);
__decorate([
    property({ type: Function })
], OakInternalWyswig.prototype, "validatorFunction", void 0);
__decorate([
    property({ type: Array })
], OakInternalWyswig.prototype, "_errors", void 0);
OakInternalWyswig = __decorate([
    customElement(customElementName)
], OakInternalWyswig);
export { OakInternalWyswig };
//# sourceMappingURL=index.js.map