export declare const oakInputBorderStyles: import("lit-element").CSSResult;
//# sourceMappingURL=border-styles.d.ts.map