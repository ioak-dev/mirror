export declare const oakInputFillStyles: import("lit-element").CSSResult;
//# sourceMappingURL=fill-styles.d.ts.map