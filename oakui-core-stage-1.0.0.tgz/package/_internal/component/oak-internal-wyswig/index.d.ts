import { LitElement } from 'lit-element';
import '../../component/oak-internal-form-tooltip';
import '../../component/oak-internal-form-error';
import 'quill/dist/quill.core.css';
import 'quill/dist/quill.snow.css';
export declare class OakInternalWyswig extends LitElement {
    private elementId;
    formGroupName?: string;
    label?: string | null | undefined;
    value?: any;
    placeholder: string;
    name: string;
    disabled: boolean;
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    shape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf' | 'underline';
    color?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'info' | 'invert' | 'danger' | 'warning' | 'success' | 'none';
    fill?: boolean | undefined;
    /**
     * 	If true, the text will have a bottom margin.
     */
    gutterBottom?: boolean;
    /**
     * Validators
     *
     */
    validatorFunction?: Function;
    /**
     * @private
     */
    private _errors;
    constructor();
    connectedCallback(): void;
    private init;
    firstUpdated(_changedProperties: any): void;
    private validate;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map