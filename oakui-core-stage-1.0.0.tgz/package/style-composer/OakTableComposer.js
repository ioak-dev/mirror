const BASE_CLASS_NAME = 'oak-table';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    if (props.baseClass) {
        output += ` ${props.baseClass}`;
    }
    if (props.dense) {
        output += ` ${BASE_CLASS_NAME}--dense`;
    }
    output += ` ${BASE_CLASS_NAME}--fill-${props.color || 'container'}`;
    if (!props.headerColor || props.headerColor === 'auto') {
        output += ` ${BASE_CLASS_NAME}--header-fill-${props.color || 'container'}`;
    }
    else {
        output += ` ${BASE_CLASS_NAME}--header-fill-${props.headerColor}`;
    }
    output += ` ${BASE_CLASS_NAME}--nav-${props.navPosition || 'none'}`;
    return output;
}
//# sourceMappingURL=OakTableComposer.js.map