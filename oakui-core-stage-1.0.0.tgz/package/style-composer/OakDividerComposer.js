const BASE_CLASS_NAME = 'oak-divider';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    output += ` ${BASE_CLASS_NAME}--color-${props.color || 'global'}`;
    output += ` ${BASE_CLASS_NAME}--mode-${props.colorMode || 'darker'}`;
    return output;
}
//# sourceMappingURL=OakDividerComposer.js.map