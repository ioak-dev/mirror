export interface OakTableProps {
    baseClass?: string;
    dense?: boolean;
    color?: 'global' | 'container' | 'surface' | 'float' | 'none';
    headerColor?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'info' | 'default' | 'invert' | 'danger' | 'warning' | 'success' | 'auto';
    navPosition?: 'none' | 'top' | 'bottom';
}
export declare function compose(props: OakTableProps): string;
//# sourceMappingURL=OakTableComposer.d.ts.map