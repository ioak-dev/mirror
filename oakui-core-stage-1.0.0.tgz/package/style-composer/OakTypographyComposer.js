const BASE_CLASS_NAME = 'oak-typography';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    if (props.baseClass) {
        output += ` ${props.baseClass}`;
    }
    output += ` ${BASE_CLASS_NAME}-root`;
    output += ` ${BASE_CLASS_NAME}-${props.variant}`;
    if (props.align) {
        output += ` ${BASE_CLASS_NAME}-align-${props.align}`;
    }
    if (props.noWrap) {
        output += ` ${BASE_CLASS_NAME}-noWrap`;
    }
    if (props.color) {
        output += ` oak-color-fg-${props.color}`;
    }
    if (props.highlightColor) {
        output += ` ${BASE_CLASS_NAME}-highlight-${props.highlightColor}`;
    }
    if (props.transform) {
        output += ` ${BASE_CLASS_NAME}-transform--${props.transform}`;
    }
    return output;
}
//# sourceMappingURL=OakTypographyComposer.js.map