export interface OakLinkProps {
    baseClass?: string;
    underlineStyle?: 'none' | 'hover' | 'always';
    textStyle?: 'none' | 'hover' | 'always';
    blockStyle?: 'none' | 'hover' | 'always';
    underlineThickness?: 'thin' | 'normal' | 'thick';
    dotted?: boolean;
    color?: 'default' | 'info' | 'invert' | 'primary' | 'secondary' | 'tertiary' | 'danger' | 'warning' | 'success';
}
export declare function compose(props: OakLinkProps): string;
//# sourceMappingURL=OakLinkComposer.d.ts.map