const BASE_CLASS_NAME = 'oak-spacing';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    output += ` ${BASE_CLASS_NAME}__padding-horizontal${props.paddingHorizontal === null ? 2 : props.paddingHorizontal}`;
    output += ` ${BASE_CLASS_NAME}__padding-vertical${props.paddingVertical === null ? 2 : props.paddingVertical}`;
    output += ` ${BASE_CLASS_NAME}__margin-horizontal${props.marginHorizontal === null ? 0 : props.marginHorizontal}`;
    output += ` ${BASE_CLASS_NAME}__margin-vertical${props.marginVertical === null ? 0 : props.marginVertical}`;
    return output;
}
//# sourceMappingURL=OakSpacingComposer.js.map