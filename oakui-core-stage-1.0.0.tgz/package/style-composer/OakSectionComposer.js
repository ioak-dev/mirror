const BASE_CLASS_NAME = 'oak-section-extern';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    if (props.baseClass) {
        output += ` ${props.baseClass}`;
    }
    output += ` oak-bs-elevation${props.elevation || 0}`;
    output += ` oak-padding-horizontal${props.paddingHorizontal === null ? 2 : props.paddingHorizontal}`;
    output += ` oak-padding-vertical${props.paddingVertical === null ? 2 : props.paddingVertical}`;
    output += ` oak-margin-horizontal${props.marginHorizontal === null ? 0 : props.marginHorizontal}`;
    output += ` oak-margin-vertical${props.marginVertical === null ? 0 : props.marginVertical}`;
    output += ` ${BASE_CLASS_NAME}--outline-${props.outlineColor || 'none'}`;
    output += ` ${BASE_CLASS_NAME}--fill-${props.fillColor || 'container'}`;
    output += ` ${BASE_CLASS_NAME}--text-${props.textColor || 'auto'}`;
    if (props.semitransparent) {
        output += ` ${BASE_CLASS_NAME}--semitransparent`;
    }
    if (props.rounded) {
        output += ' oak-rounded';
    }
    if (props.gutterBottom) {
        output += ' oak-gutter-bottom';
    }
    if (props.fullWidth) {
        output += ` ${BASE_CLASS_NAME}--fullwidth`;
    }
    return output;
}
//# sourceMappingURL=OakSectionComposer.js.map