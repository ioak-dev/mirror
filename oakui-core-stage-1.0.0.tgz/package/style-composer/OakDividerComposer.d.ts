export interface OakDividerProps {
    colorMode?: 'darker' | 'lighter' | 'even' | 'i';
    color?: 'none' | 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info' | 'invert';
}
export declare function compose(props: OakDividerProps): string;
//# sourceMappingURL=OakDividerComposer.d.ts.map