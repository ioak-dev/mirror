const BASE_CLASS_NAME = 'oak-link';
export function compose(props) {
    let output = BASE_CLASS_NAME;
    if (props.baseClass) {
        output += ` ${props.baseClass}`;
    }
    output += ` ${BASE_CLASS_NAME}--underline-${props.underlineStyle || 'hover'}`;
    if (props.dotted) {
        output += ` ${BASE_CLASS_NAME}--dotted`;
    }
    output += ` ${BASE_CLASS_NAME}--underline-thickness-${props.underlineThickness || 'normal'}`;
    output += ` ${BASE_CLASS_NAME}--text-${props.textStyle || 'always'}`;
    output += ` ${BASE_CLASS_NAME}--color-${props.color || 'primary'}`;
    output += ` ${BASE_CLASS_NAME}--block-${props.blockStyle || 'none'}`;
    return output;
}
//# sourceMappingURL=OakLinkComposer.js.map