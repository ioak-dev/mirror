export declare function base64ToFile(base64Content: string): Blob;
export declare function fileToBase64(): null;
//# sourceMappingURL=OakImageService.d.ts.map