export function base64ToFile(base64Content) {
    const split = base64Content.split(',');
    const type = split[0].replace('data:', '').replace(';base64', '');
    const byteValue = atob(split[1]);
    const buffer = new ArrayBuffer(byteValue.length);
    const bufferArray = new Uint8Array(buffer);
    for (let i = 0; i < byteValue.length; i += 1) {
        bufferArray[i] = byteValue.charCodeAt(i);
    }
    return new Blob([buffer], { type });
}
export function fileToBase64() {
    return null;
}
//# sourceMappingURL=OakImageService.js.map