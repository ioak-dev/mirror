import { LitElement } from 'lit-element';
import '../oak-button';
export declare class OakAppLayout extends LitElement {
    private elementId;
    topbarVariant: 'sticky' | 'static' | 'auto' | 'none';
    sidebarVariant: 'side' | 'over' | 'push' | 'none';
    sidebarOutlined?: boolean | undefined;
    topbarOutlined?: boolean | undefined;
    topbarColor: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info' | 'invert' | 'custom';
    sidebarColor: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info' | 'invert' | 'custom';
    topbarElevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    sidebarElevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    sidebarToggleIconVariant: 'arrow' | 'chevron' | 'menu' | 'menu-with-arrow';
    private _isSidebarOpen;
    constructor();
    private _renderBackdrop;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    private _toggleSidebar;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map