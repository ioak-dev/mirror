export declare const oakAppLayoutBorderStyles: import("lit-element").CSSResult;
//# sourceMappingURL=border-styles.d.ts.map