var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { globalStyles } from '../../_internal/styles/global-styles';
import '../../_internal/component/oak-internal-select-native';
import '../../_internal/component/oak-internal-select-modern';
import { oakSelectStyles } from './index-styles';
let elementIdCounter = 0;
const customElementName = 'oak-select';
/**
 * Select drop down (native) form element.
 *
 */
let OakSelect = class OakSelect extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.id = `${customElementName}-${elementIdCounter++}-id`;
        this.label = null;
        this.placeholder = '';
        this.multiple = false;
        this.tooltip = '';
        this.name = this.elementId;
        this.disabled = false;
        this.native = false;
        this.fill = false;
        this.size = 'small';
        this.shape = 'rectangle';
        this.color = 'container';
        this.popupColor = 'auto';
        this.autocomplete = false;
        this.positioningStrategy = 'absolute';
        /**
         * 	If true, the text will have a bottom margin.
         */
        this.gutterBottom = false;
    }
    static get styles() {
        return [...globalStyles, oakSelectStyles];
    }
    render() {
        return html `
      ${this.native
            ? html `<oak-internal-select-native
            .formGroupName=${this.formGroupName}
            .label=${this.label}
            .name=${this.name}
            .value=${this.value}
            .values=${this.values}
            .placeholder=${this.placeholder}
            .tooltip=${this.tooltip}
            ?multiple=${this.multiple}
            ?disabled=${this.disabled}
            ?fill=${this.fill}
            .options=${this.options}
            .optionsAsKeyValue=${this.optionsAsKeyValue}
            .size=${this.size}
            .shape=${this.shape}
            .color=${this.color}
            .popupColor=${this.popupColor}
            ?gutterBottom=${this.gutterBottom}
            .actionItems=${this.actionItems}
          ></oak-internal-select-native>`
            : html `<oak-internal-select-modern
            .formGroupName=${this.formGroupName}
            .label=${this.label}
            .name=${this.name}
            .value=${this.value}
            .values=${this.values}
            .placeholder=${this.placeholder}
            .tooltip=${this.tooltip}
            ?multiple=${this.multiple}
            ?disabled=${this.disabled}
            ?fill=${this.fill}
            .options=${this.options}
            .optionsAsKeyValue=${this.optionsAsKeyValue}
            .size=${this.size}
            .shape=${this.shape}
            .color=${this.color}
            .popupColor=${this.popupColor}
            .autocomplete=${this.autocomplete}
            .positioningStrategy=${this.positioningStrategy}
            ?gutterBottom=${this.gutterBottom}
            .actionItems=${this.actionItems}
          ></oak-internal-select-modern>`}
    `;
    }
};
__decorate([
    property({ type: String, reflect: true })
], OakSelect.prototype, "id", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "formGroupName", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "label", void 0);
__decorate([
    property()
], OakSelect.prototype, "value", void 0);
__decorate([
    property()
], OakSelect.prototype, "values", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "actionItems", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "placeholder", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "multiple", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "tooltip", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "name", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "disabled", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "options", void 0);
__decorate([
    property({ type: Array })
], OakSelect.prototype, "optionsAsKeyValue", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "native", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "fill", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "size", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "shape", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "color", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "popupColor", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "autocomplete", void 0);
__decorate([
    property({ type: String })
], OakSelect.prototype, "positioningStrategy", void 0);
__decorate([
    property({ type: Boolean })
], OakSelect.prototype, "gutterBottom", void 0);
OakSelect = __decorate([
    customElement(customElementName)
], OakSelect);
export { OakSelect };
//# sourceMappingURL=index.js.map