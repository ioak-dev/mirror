import { LitElement } from 'lit-element';
import '../../_internal/component/oak-internal-popup';
import '../oak-click-area';
import '../oak-button';
/**
 * Select drop down (native) form element.
 *
 */
export declare class OakMenu extends LitElement {
    private elementId;
    type?: 'button' | 'custom';
    buttonVariant?: 'block' | 'outline' | 'appear' | 'disappear' | 'regular' | 'disabled' | 'drama';
    buttonTheme?: 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info';
    buttonSize?: 'xsmall' | 'small' | 'medium' | 'large';
    buttonShape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf' | 'icon';
    buttonSemitransparent: boolean;
    buttonFullWidth: boolean;
    buttonElevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    positioningStrategy?: 'absolute' | 'fixed';
    private _isActivated;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    private _activate;
    private _deactivate;
    private handleClick;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map