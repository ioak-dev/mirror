var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../_internal/styles/global-styles';
import '../../_internal/component/oak-internal-popup';
import '../oak-click-area';
import '../oak-button';
import { oakMenuStyles } from './index-styles';
let elementIdCounter = 0;
const customElementName = 'oak-menu';
/**
 * Select drop down (native) form element.
 *
 */
let OakMenu = class OakMenu extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.type = 'button';
        this.buttonVariant = 'regular';
        this.buttonTheme = 'primary';
        this.buttonSize = 'small';
        this.buttonShape = 'rectangle';
        this.buttonSemitransparent = false;
        this.buttonFullWidth = false;
        this.buttonElevation = 0;
        this.positioningStrategy = 'absolute';
        this._isActivated = false;
        this._activate = () => {
            this._isActivated = true;
        };
        this._deactivate = () => {
            this._isActivated = false;
        };
        this.handleClick = () => {
            this._isActivated ? this._deactivate() : this._activate();
        };
        this.getClassMap = (baseClass) => {
            switch (baseClass) {
                case 'base':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'popup':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'ul':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                default:
                    return {};
            }
        };
    }
    connectedCallback() {
        super.connectedCallback();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    static get styles() {
        return [...globalStyles, oakMenuStyles];
    }
    render() {
        return html `
      <oak-internal-popup
        @popup-activate=${this._activate}
        @popup-deactivate=${this._deactivate}
        ?isActivated=${this._isActivated}
        .positioningStrategy=${this.positioningStrategy}
        type="custom"
      >
        <div slot="action">
          ${this.type === 'custom'
            ? html ` <div>
                <oak-click-area @click-area-click=${this.handleClick}
                  ><slot name="menu-label"></slot
                ></oak-click-area>
              </div>`
            : html `
                <oak-button
                  type="button"
                  .variant=${this.buttonVariant}
                  .theme=${this.buttonTheme}
                  .size=${this.buttonSize}
                  .shape=${this.buttonShape}
                  ?semitransparent=${this.buttonSemitransparent}
                  ?fullWidth=${this.buttonFullWidth}
                  .elevation=${this.buttonElevation}
                  @button-click=${this.handleClick}
                >
                  <slot name="menu-label"></slot>
                </oak-button>
              `}
        </div>
        <div
          slot="popup"
          class=${classMap(this.getClassMap('popup'))}
          id=${this.elementId}
        >
          <slot name="menu-popup"></slot>
        </div>
      </oak-internal-popup>
    `;
    }
};
__decorate([
    property({ type: String })
], OakMenu.prototype, "type", void 0);
__decorate([
    property({ type: String })
], OakMenu.prototype, "buttonVariant", void 0);
__decorate([
    property({ type: String })
], OakMenu.prototype, "buttonTheme", void 0);
__decorate([
    property({ type: String })
], OakMenu.prototype, "buttonSize", void 0);
__decorate([
    property({ type: String })
], OakMenu.prototype, "buttonShape", void 0);
__decorate([
    property({ type: Boolean })
], OakMenu.prototype, "buttonSemitransparent", void 0);
__decorate([
    property({ type: Boolean })
], OakMenu.prototype, "buttonFullWidth", void 0);
__decorate([
    property({ type: Number })
], OakMenu.prototype, "buttonElevation", void 0);
__decorate([
    property({ type: String })
], OakMenu.prototype, "positioningStrategy", void 0);
__decorate([
    property({ type: Boolean })
], OakMenu.prototype, "_isActivated", void 0);
OakMenu = __decorate([
    customElement(customElementName)
], OakMenu);
export { OakMenu };
//# sourceMappingURL=index.js.map