export declare const oakImageUploadCropperStyles: import("lit-element").CSSResult;
//# sourceMappingURL=cropper-style.d.ts.map