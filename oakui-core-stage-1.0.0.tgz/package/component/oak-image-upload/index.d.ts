import { LitElement } from 'lit-element';
import '../oak-input';
import '../oak-button';
import '../oak-click-area';
export declare class OakImageUpload extends LitElement {
    private elementId;
    private inputElementId;
    toolbarPosition?: 'top' | 'bottom' | 'left' | 'right';
    private _cropUrl;
    private _file;
    private _canvas;
    private _cropper;
    constructor();
    private _chooseFile;
    private _triggerBrowse;
    private _chooseFileManual;
    private _startCrop;
    private _finalizeCrop;
    private _clearFile;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map