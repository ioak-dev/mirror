export declare const oakImageUploadStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map