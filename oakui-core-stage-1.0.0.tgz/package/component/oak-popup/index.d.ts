import { LitElement } from 'lit-element';
import '../../_internal/component/oak-internal-popup';
import '../oak-click-area';
import '../oak-button';
/**
 * Popup element.
 *
 */
export declare class OakPopup extends LitElement {
    private elementId;
    private inputElementId;
    private popupElementId;
    private _isActivated;
    options: any[];
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    shape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf';
    fill?: 'container' | 'surface' | 'float' | 'none';
    /**
     * 	If true, the text will have a bottom margin.
     */
    gutterBottom?: boolean;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    firstUpdated(_changedProperties: any): void;
    private _mountPopper;
    private handleClick;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map