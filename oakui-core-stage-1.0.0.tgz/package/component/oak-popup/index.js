var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { createPopper } from '@popperjs/core';
import { globalStyles } from '../../_internal/styles/global-styles';
import '../../_internal/component/oak-internal-popup';
import '../oak-click-area';
import '../oak-button';
import { oakPopupStyles } from './index-styles';
let elementIdCounter = 0;
const customElementName = 'oak-popup';
/**
 * Popup element.
 *
 */
let OakPopup = class OakPopup extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.inputElementId = `${this.elementId}-input`;
        this.popupElementId = `${this.elementId}-popup`;
        this._isActivated = false;
        this.options = [];
        this.size = 'small';
        this.shape = 'rectangle';
        this.fill = 'surface';
        /**
         * 	If true, the text will have a bottom margin.
         */
        this.gutterBottom = false;
        this.handleClick = () => {
            // this._isActivated ? this._deactivate() : this._activate();
            this._isActivated = !this._isActivated;
        };
        this.getClassMap = (baseClass) => {
            switch (baseClass) {
                case 'base':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'popup':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'trigger':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                case 'trigger-wrapper':
                    return {
                        [`${customElementName}__${baseClass}`]: true,
                    };
                default:
                    return {};
            }
        };
    }
    connectedCallback() {
        super.connectedCallback();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        setTimeout(() => this._mountPopper());
    }
    _mountPopper() {
        var _a, _b;
        const trigger = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(`${this.inputElementId}`);
        const popup = (_b = this.shadowRoot) === null || _b === void 0 ? void 0 : _b.getElementById(`${this.popupElementId}`);
        console.log('*****************', trigger, popup);
        if (trigger && popup) {
            createPopper(trigger, popup, { placement: 'top' });
        }
    }
    static get styles() {
        return [...globalStyles, oakPopupStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        abcd one
        <div class=${classMap(this.getClassMap('trigger-wrapper'))}>
          <oak-click-area
            @click-area-click=${this.handleClick}
            id=${this.inputElementId}
          >
            <div class=${classMap(this.getClassMap('trigger'))}>
              <slot name="trigger"></slot>
            </div>
          </oak-click-area>
        </div>
        abcd two
        <div
          class=${classMap(this.getClassMap('popup'))}
          id=${this.popupElementId}
        >
          ${this._isActivated ? html ` <slot name="popup"></slot>` : html ``}
        </div>
        abcd three
      </div>
    `;
    }
};
__decorate([
    property({ type: Boolean })
], OakPopup.prototype, "_isActivated", void 0);
__decorate([
    property({ type: Array })
], OakPopup.prototype, "options", void 0);
__decorate([
    property({ type: String })
], OakPopup.prototype, "size", void 0);
__decorate([
    property({ type: String })
], OakPopup.prototype, "shape", void 0);
__decorate([
    property({ type: String })
], OakPopup.prototype, "fill", void 0);
__decorate([
    property({ type: Boolean })
], OakPopup.prototype, "gutterBottom", void 0);
OakPopup = __decorate([
    customElement(customElementName)
], OakPopup);
export { OakPopup };
//# sourceMappingURL=index.js.map