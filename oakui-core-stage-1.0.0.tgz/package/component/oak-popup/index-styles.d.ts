export declare const oakPopupStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map