var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { EXPANSE_COLLAPSED_EVENT, EXPANSE_EXPANDED_EVENT, } from '../../event/OakExpanseEvent';
import { expanseExpandedSubject } from '../../_internal/events/ExpanseExpandedEvent';
import { globalStyles } from '../../_internal/styles/global-styles';
import { isEmptyOrSpaces } from '../../_internal/utils/StringUtils';
import { oakExpanseStyles } from './index-styles';
import '../oak-click-area';
import { expanseRecomputeSubject } from '../../_internal/events/ExpanseRecomputeEvent';
let elementIdCounter = 0;
/**
 * Expanse component.
 *
 */
const customElementName = 'oak-expanse';
let OakExpanse = class OakExpanse extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.mainElementId = `${customElementName}-${elementIdCounter++}--main`;
        this.name = null;
        this.groupName = null;
        this.defaultState = 'collapsed';
        this.elevation = 1;
        this._isExpanded = false;
        this._propagateEvent = (eventName, value) => {
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail: {
                    id: this.elementId,
                    name: this.name,
                    groupName: this.groupName,
                    value,
                },
            }));
        };
    }
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        if (this.defaultState === 'expanded') {
            this._toggle();
        }
    }
    init() {
        if (!isEmptyOrSpaces(this.groupName)) {
            expanseExpandedSubject.asObservable().subscribe((message) => {
                if (message.groupName === this.groupName &&
                    message.elementId !== this.elementId &&
                    this._isExpanded) {
                    this._toggle();
                }
            });
            expanseRecomputeSubject.asObservable().subscribe((message) => {
                if (message.groupName === this.groupName &&
                    message.name === this.name) {
                    console.log(message, this.name, this.groupName);
                    setTimeout(() => {
                        this._updateScrollHeight();
                    }, 300);
                }
            });
        }
    }
    // private _handleChange = () => {
    //   this.propagateEvent(INPUT_CHANGE_EVENT);
    // };
    _toggle() {
        const _isExpanded = this._isExpanded;
        if (!_isExpanded && !isEmptyOrSpaces(this.groupName)) {
            expanseExpandedSubject.next({
                elementId: this.elementId,
                groupName: this.groupName,
            });
        }
        if (_isExpanded) {
            this._propagateEvent(EXPANSE_COLLAPSED_EVENT, false);
        }
        else {
            this._propagateEvent(EXPANSE_EXPANDED_EVENT, true);
        }
        this._isExpanded = !_isExpanded;
        this._updateScrollHeight();
    }
    _updateScrollHeight() {
        var _a;
        const mainElRef = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById(this.mainElementId);
        setTimeout(() => {
            if (this._isExpanded && mainElRef) {
                mainElRef.style.maxHeight = mainElRef.scrollHeight + 'px';
                mainElRef.style.overflowY = 'hidden';
                mainElRef.style.visibility = 'visible';
                setTimeout(() => {
                    mainElRef.style.overflowY = 'visible';
                }, 300);
            }
            else if (mainElRef) {
                mainElRef.style.maxHeight = '0px';
                mainElRef.style.overflowY = 'hidden';
                setTimeout(() => {
                    mainElRef.style.visibility = 'hidden';
                }, 300);
            }
        }, 0);
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                    [`oak-bs-elevation${this.elevation}`]: true,
                    'oak-rounded': this.rounded,
                    'oak-outlined': this.outlined,
                };
            case 'header':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            case 'main':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [...globalStyles, oakExpanseStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <div class=${classMap(this.getClassMap('header'))}>
          <oak-click-area @click-area-click=${this._toggle}>
            <slot name="header"></slot>
          </oak-click-area>
        </div>
        <div
          class=${classMap(this.getClassMap('main'))}
          id=${this.mainElementId}
        >
          <slot name="main"></slot>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], OakExpanse.prototype, "name", void 0);
__decorate([
    property({ type: String })
], OakExpanse.prototype, "groupName", void 0);
__decorate([
    property({ type: String })
], OakExpanse.prototype, "defaultState", void 0);
__decorate([
    property({ type: Boolean })
], OakExpanse.prototype, "rounded", void 0);
__decorate([
    property({ type: Boolean })
], OakExpanse.prototype, "outlined", void 0);
__decorate([
    property({ type: Number })
], OakExpanse.prototype, "elevation", void 0);
__decorate([
    property({ type: Boolean })
], OakExpanse.prototype, "_isExpanded", void 0);
OakExpanse = __decorate([
    customElement(customElementName)
], OakExpanse);
export { OakExpanse };
//# sourceMappingURL=index.js.map