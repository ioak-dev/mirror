import { LitElement } from 'lit-element';
import '../oak-click-area';
export declare class OakExpanse extends LitElement {
    private elementId;
    private mainElementId;
    name?: string | null;
    groupName?: string | null;
    defaultState: 'expanded' | 'collapsed';
    rounded?: false;
    outlined?: false;
    elevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    private _isExpanded;
    constructor();
    connectedCallback(): void;
    firstUpdated(_changedProperties: any): void;
    private init;
    private _toggle;
    private _updateScrollHeight;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map