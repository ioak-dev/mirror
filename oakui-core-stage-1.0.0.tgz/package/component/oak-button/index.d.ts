import { LitElement } from 'lit-element';
import '../oak-label';
/**
 * Button element.
 *
 */
export declare class OakButton extends LitElement {
    private elementId;
    variant?: 'block' | 'outline' | 'appear' | 'disappear' | 'regular' | 'disabled' | 'drama';
    theme?: 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info';
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    shape?: 'sharp' | 'rectangle' | 'rounded' | 'leaf' | 'icon';
    semitransparent: boolean;
    fullWidth: boolean;
    type: 'button' | 'submit' | 'reset';
    formGroupName?: string;
    elevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    computeStyle: () => string;
    constructor();
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    private handleClick;
    private handleSubmit;
    private handleReset;
    private propagateEvent;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map