var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { globalStyles } from '../../_internal/styles/global-styles';
import { oakLabelStyles } from './index-styles';
let elementIdCounter = 0;
/**
 * Label for form elements.
 *
 */
const customElementName = 'oak-label';
let OakLabel = class OakLabel extends LitElement {
    constructor() {
        super();
        this.label = null;
        this.noMargin = false;
        this.elementFor = '';
        this.elementId = `${customElementName}-${elementIdCounter++}`;
    }
    static get styles() {
        return [...globalStyles, oakLabelStyles];
    }
    render() {
        return html ` ${this.label
            ? html `<label
          for=${this.elementFor}
          id=${this.elementId}
          class=${`${this.noMargin ? 'no-margin' : ''}`}
          >${this.label}</label
        >`
            : html ``}`;
    }
};
__decorate([
    property({ type: String })
], OakLabel.prototype, "label", void 0);
__decorate([
    property({ type: Boolean })
], OakLabel.prototype, "noMargin", void 0);
__decorate([
    property({ type: String })
], OakLabel.prototype, "elementFor", void 0);
OakLabel = __decorate([
    customElement(customElementName)
], OakLabel);
export { OakLabel };
//# sourceMappingURL=index.js.map