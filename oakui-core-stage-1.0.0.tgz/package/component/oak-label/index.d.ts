import { LitElement } from 'lit-element';
export declare class OakLabel extends LitElement {
    label?: string | null | undefined;
    noMargin?: boolean | undefined;
    elementFor: string;
    private elementId;
    constructor();
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map