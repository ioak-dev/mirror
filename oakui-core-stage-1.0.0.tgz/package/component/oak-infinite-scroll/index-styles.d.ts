export declare const oakInfiniteScrollStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map