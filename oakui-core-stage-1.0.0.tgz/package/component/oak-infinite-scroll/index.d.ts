import { LitElement } from 'lit-element';
import { PaginatePref } from '../../types/PaginatePrefType';
export declare class OakInfiniteScroll extends LitElement {
    private elementId;
    customSelector?: string | null;
    variant: 'auto-selector' | 'custom-selector' | 'body-selector';
    paginatePref: PaginatePref;
    private _isFetching;
    constructor();
    firstUpdated(changedProperties: any): void;
    shouldUpdate(_changedProperties: Map<string | number | symbol, unknown>): boolean;
    private init;
    private _findSelectorType;
    private _handleScroll;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map