var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../_internal/styles/global-styles';
import { oakInfiniteScrollStyles } from './index-styles';
import { fromEvent } from 'rxjs';
import { map } from 'rxjs/operators';
import { INFINITE_SCROLL_CHANGE_EVENT } from '../../event/OakInfiniteScrollEvent';
let elementIdCounter = 0;
/**
 * Infinite scroll component.
 *
 */
const customElementName = 'oak-infinite-scroll';
let OakInfiniteScroll = class OakInfiniteScroll extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.customSelector = null;
        this.variant = 'auto-selector';
        this.paginatePref = {
            pageNo: 1,
            rowsPerPage: 5,
            searchText: '',
        };
        this._isFetching = false;
        this.init = () => {
            var _a, _b, _c;
            switch (this._findSelectorType()) {
                case 'auto':
                    (_b = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelector(`#${this.elementId}`)) === null || _b === void 0 ? void 0 : _b.addEventListener('scroll', () => this._handleScroll('auto'));
                    break;
                case 'custom':
                    (_c = document === null || document === void 0 ? void 0 : document.querySelector(this.customSelector || '')) === null || _c === void 0 ? void 0 : _c.addEventListener('scroll', () => this._handleScroll('custom'));
                    break;
                case 'body':
                    fromEvent(window, 'scroll')
                        .pipe(map((event) => event))
                        .subscribe(() => this._handleScroll('body'));
                    break;
                default:
                    break;
            }
        };
        this._findSelectorType = () => {
            if (this.variant === 'auto-selector' ||
                (this.variant == 'custom-selector' && !this.customSelector)) {
                return 'auto';
            }
            else if (this.variant === 'custom-selector' && this.customSelector) {
                return 'custom';
            }
            else {
                return 'body';
            }
        };
        this._handleScroll = (selectorType) => {
            var _a;
            let selectorEl = null;
            switch (selectorType) {
                case 'auto':
                    selectorEl = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelector(`#${this.elementId}`);
                    break;
                case 'custom':
                    selectorEl = document === null || document === void 0 ? void 0 : document.querySelector(this.customSelector || '');
                    break;
                case 'body':
                default:
                    selectorEl = window.document.documentElement;
            }
            if (!selectorEl) {
                return;
            }
            const outcome = (selectorEl.clientHeight || 0) + (selectorEl.scrollTop || 0) >=
                (selectorEl.scrollHeight || 0) - 2;
            if (outcome) {
                if (!this._isFetching) {
                    this._isFetching = true;
                    this._propagateEvent(INFINITE_SCROLL_CHANGE_EVENT, {
                        id: this.elementId,
                    });
                    setTimeout(() => {
                        this._isFetching = false;
                    }, 1000);
                }
            }
        };
        // private _pageChanged = (_paginatePref: PaginatePref) => {
        //   this._propagateEvent(INFINITE_SCROLL_CHANGE_EVENT, _paginatePref);
        // };
        this._propagateEvent = (eventName, detail) => {
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail,
            }));
        };
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        setTimeout(() => this.init());
    }
    shouldUpdate(_changedProperties) {
        _changedProperties.forEach((_, propName) => {
            if (propName === 'customSelector') {
                this.init();
            }
        });
        return true;
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                const data = {
                    [customElementName]: true,
                    [`${customElementName}--native-scroll`]: this._findSelectorType() === 'auto',
                };
                return data;
            default:
                return {};
        }
    }
    static get styles() {
        return [...globalStyles, oakInfiniteScrollStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <slot></slot>
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], OakInfiniteScroll.prototype, "customSelector", void 0);
__decorate([
    property({ type: String })
], OakInfiniteScroll.prototype, "variant", void 0);
__decorate([
    property({ type: Object })
], OakInfiniteScroll.prototype, "paginatePref", void 0);
__decorate([
    property({ type: Boolean })
], OakInfiniteScroll.prototype, "_isFetching", void 0);
OakInfiniteScroll = __decorate([
    customElement(customElementName)
], OakInfiniteScroll);
export { OakInfiniteScroll };
//# sourceMappingURL=index.js.map