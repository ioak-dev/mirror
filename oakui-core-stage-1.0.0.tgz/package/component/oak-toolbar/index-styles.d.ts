export declare const oakToolbarStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map