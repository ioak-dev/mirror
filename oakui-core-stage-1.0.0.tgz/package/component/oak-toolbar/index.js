var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../_internal/styles/global-styles';
import { oakToolbarStyles } from './index-styles';
let elementIdCounter = 0;
/**
 * Click area component.
 *
 */
const customElementName = 'oak-toolbar';
let OakToolbar = class OakToolbar extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.borderVariant = 'none';
        this.fillColor = 'global';
        this.paddingHorizontal = 1;
        this.paddingVertical = 1;
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                    [`oak-bs-elevation${this.elevation || 0}`]: true,
                    [`oak-padding-horizontal${this.paddingHorizontal}`]: true,
                    [`oak-padding-vertical${this.paddingVertical}`]: true,
                    [`${customElementName}--bordervariant-${this.borderVariant}`]: true,
                    [`oak-color-bg-${this.fillColor}`]: true,
                    [`oak-color-${this.fillColor}-i`]: true,
                };
            case 'left':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            case 'right':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [...globalStyles, oakToolbarStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <div class=${classMap(this.getClassMap('left'))}>
          <slot name="left"></slot>
        </div>
        <div class=${classMap(this.getClassMap('right'))}>
          <slot name="right"></slot>
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: Number })
], OakToolbar.prototype, "elevation", void 0);
__decorate([
    property({ type: String })
], OakToolbar.prototype, "borderVariant", void 0);
__decorate([
    property({ type: String })
], OakToolbar.prototype, "fillColor", void 0);
__decorate([
    property({ type: Number })
], OakToolbar.prototype, "paddingHorizontal", void 0);
__decorate([
    property({ type: Number })
], OakToolbar.prototype, "paddingVertical", void 0);
OakToolbar = __decorate([
    customElement(customElementName)
], OakToolbar);
export { OakToolbar };
//# sourceMappingURL=index.js.map