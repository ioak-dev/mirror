var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../_internal/styles/global-styles';
import { oakNavElementStyles } from './index-styles';
import '../oak-click-area';
import '../oak-expanse';
import { BUTTON_CLICK_EVENT } from '../../event/OakButtonEvent';
let elementIdCounter = 0;
/**
 * Nav element component.
 *
 */
const customElementName = 'oak-nav-element';
let OakNavElement = class OakNavElement extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.active = false;
        this.level = 1;
        this._handleClick = () => {
            this._propagateEvent(BUTTON_CLICK_EVENT);
        };
        this._propagateEvent = (eventName) => {
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail: {
                    id: this.elementId,
                },
            }));
        };
    }
    connectedCallback() {
        super.connectedCallback();
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                };
            case 'container':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`${customElementName}__${baseClass}--active`]: this.active,
                    [`${customElementName}__${baseClass}--level-${this.level}`]: true,
                };
            case 'content':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`${customElementName}__${baseClass}--level-${this.level}`]: true,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [...globalStyles, oakNavElementStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <oak-click-area @click-area-click=${this._handleClick}
          ><div class=${classMap(this.getClassMap('container'))}>
            <div class=${classMap(this.getClassMap('content'))}>
              <div>
                <slot></slot>
              </div>
            </div></div
        ></oak-click-area>
      </div>
    `;
    }
};
__decorate([
    property({ type: Boolean })
], OakNavElement.prototype, "active", void 0);
__decorate([
    property({ type: Number })
], OakNavElement.prototype, "level", void 0);
OakNavElement = __decorate([
    customElement(customElementName)
], OakNavElement);
export { OakNavElement };
//# sourceMappingURL=index.js.map