export declare const oakNavElementStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map