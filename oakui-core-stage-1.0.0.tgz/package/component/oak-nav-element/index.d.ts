import { LitElement } from 'lit-element';
import '../oak-click-area';
import '../oak-expanse';
export declare class OakNavElement extends LitElement {
    private elementId;
    active: boolean;
    level: 1 | 2 | 3;
    constructor();
    connectedCallback(): void;
    private _handleClick;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map