import { LitElement } from 'lit-element';
export declare class OakRadio extends LitElement {
    private elementId;
    name: string;
    color?: 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info';
    size?: 'xsmall' | 'small' | 'medium' | 'large';
    /**
     * 	If true, the element will have a bottom margin.
     */
    gutterBottom?: boolean;
    radioGroupName: string;
    private value;
    private _value;
    private _subscriptions;
    constructor();
    connectedCallback(): void;
    disconnectedCallback(): void;
    private init;
    shouldUpdate(_changedProperties: Map<string | number | symbol, unknown>): boolean;
    private _handleChange;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map