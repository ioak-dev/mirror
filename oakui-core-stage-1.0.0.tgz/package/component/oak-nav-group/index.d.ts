import { LitElement } from 'lit-element';
import '../oak-click-area';
import '../oak-expanse';
export declare class OakNavGroup extends LitElement {
    private elementId;
    name: string;
    groupName?: string | null;
    parentName?: string | null;
    parentGroupName?: string | null;
    level: 1 | 2 | 3;
    defaultState: 'expanded' | 'collapsed';
    private _isExpanded;
    constructor();
    connectedCallback(): void;
    private _expand;
    private _collapse;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map