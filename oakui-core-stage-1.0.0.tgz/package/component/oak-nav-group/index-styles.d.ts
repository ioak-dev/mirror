export declare const oakNavGroupStyles: import("lit-element").CSSResult;
//# sourceMappingURL=index-styles.d.ts.map