var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { CLICK_AREA_CLICK_EVENT } from '../../event/OakClickAreaEvent';
import { globalStyles } from '../../_internal/styles/global-styles';
import { oakClickAreaStyles } from './index-styles';
let elementIdCounter = 0;
/**
 * Click area component.
 *
 */
const customElementName = 'oak-click-area';
let OakClickArea = class OakClickArea extends LitElement {
    constructor() {
        super();
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this._handleClick = () => {
            this._propagateEvent(CLICK_AREA_CLICK_EVENT);
        };
        this._propagateEvent = (eventName) => {
            this.dispatchEvent(new CustomEvent(eventName, {
                bubbles: true,
                composed: true,
                detail: {
                    id: this.elementId,
                },
            }));
        };
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                };
            case 'container':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            case 'button-content':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [...globalStyles, oakClickAreaStyles];
    }
    render() {
        return html `
      <div class=${classMap(this.getClassMap('base'))} id=${this.elementId}>
        <div class=${classMap(this.getClassMap('container'))}>
          <button @click=${this._handleClick}>
            <div class=${classMap(this.getClassMap('button-content'))}>
              <slot></slot>
            </div>
          </button>
        </div>
      </div>
    `;
    }
};
OakClickArea = __decorate([
    customElement(customElementName)
], OakClickArea);
export { OakClickArea };
//# sourceMappingURL=index.js.map