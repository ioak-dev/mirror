import { LitElement } from 'lit-element';
export declare class OakClickArea extends LitElement {
    private elementId;
    constructor();
    private _handleClick;
    private _propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map