export declare const oakModalAnimationSlideStyles: import("lit-element").CSSResult;
//# sourceMappingURL=animation-slide-styles.d.ts.map