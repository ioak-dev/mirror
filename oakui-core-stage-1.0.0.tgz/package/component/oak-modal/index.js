var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map';
import { globalStyles } from '../../_internal/styles/global-styles';
import ModalEvent from '../../event/OakModalEvent';
import { oakModalStyles } from './index-styles';
import '../../_internal/component/oak-internal-modal-header';
import '../../_internal/component/oak-internal-modal-body';
import '../../_internal/component/oak-internal-modal-footer';
import { fromEvent } from 'rxjs';
import { map } from 'rxjs/operators';
import { oakModalAnimationSlideStyles } from './animation-slide-styles';
import { oakModalAnimationZoomStyles } from './animation-zoom-styles';
import { oakModalAnimationOpacityStyles } from './animation-opacity-styles';
let elementIdCounter = 0;
/**
 * Text box form element.
 *
 */
const customElementName = 'oak-modal';
let OakModal = class OakModal extends LitElement {
    constructor() {
        super(...arguments);
        this.elementId = `${customElementName}-${elementIdCounter++}`;
        this.isOpen = false;
        this.rounded = false;
        this.height = 'auto';
        this.width = 'auto';
        this.animationSpeed = 'normal';
        this.animationStyle = 'opacity';
        this.color = 'surface';
        this.backdropIntensity = 2;
        this.paddingHorizontal = 4;
        this.paddingVertical = 4;
        this.elevation = 10;
        this._isOpen = false;
        this._handleClose = () => {
            this.propagateEvent(ModalEvent.CLOSE_MODAL, { value: true });
        };
        this.propagateEvent = (eventType, event) => {
            this.dispatchEvent(new CustomEvent(eventType, {
                bubbles: true,
                composed: true,
                detail: {
                    id: this.elementId,
                    name: eventType,
                    value: event.value,
                },
            }));
        };
    }
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    init() {
        fromEvent(window, 'keydown')
            .pipe(map((event) => event))
            .subscribe((event) => {
            if (['Escape'].includes(event.key)) {
                this._handleClose();
            }
        });
    }
    shouldUpdate(_changedProperties) {
        _changedProperties.forEach((_, propName) => {
            if (propName === 'isOpen') {
                if (this.isOpen) {
                    this._isOpen = true;
                }
                else {
                    let timeout = 0;
                    if (this.animationSpeed === 'slow') {
                        timeout = 650;
                    }
                    if (this.animationSpeed === 'normal') {
                        timeout = 350;
                    }
                    if (this.animationSpeed === 'fast') {
                        timeout = 200;
                    }
                    setTimeout(() => {
                        this._isOpen = false;
                    }, timeout);
                }
            }
        });
        return true;
    }
    getClassMap(baseClass) {
        switch (baseClass) {
            case 'base':
                return {
                    [customElementName]: true,
                    [`${customElementName}--speed-${this.animationSpeed}`]: true,
                    [`${customElementName}--animation-${this.animationStyle}`]: true,
                    show: this.isOpen,
                    hide: !this.isOpen,
                };
            case 'container':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            case 'backdrop':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`oak-backdrop-${this.backdropIntensity}`]: this.width !== 'full' || this.height !== 'full',
                };
            case 'content':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                };
            case 'content-container':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`${customElementName}__${baseClass}--height-${this.height}`]: true,
                    [`${customElementName}__${baseClass}--width-${this.width}`]: true,
                    [`${customElementName}__${baseClass}--rounded`]: this.rounded,
                    [`oak-color-bg-${this.color}`]: true,
                    [`oak-color-${this.color}-i`]: true,
                    [`oak-bs-elevation${this.elevation}`]: true,
                };
            case 'heading':
            case 'footer':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`oak-padding-horizontal${this.paddingHorizontal}`]: true,
                };
            case 'body':
                return {
                    [`${customElementName}__${baseClass}`]: true,
                    [`oak-padding-horizontal${this.paddingHorizontal}`]: true,
                    [`oak-padding-vertical${this.paddingVertical}`]: true,
                };
            default:
                return {};
        }
    }
    static get styles() {
        return [
            ...globalStyles,
            oakModalStyles,
            oakModalAnimationOpacityStyles,
            oakModalAnimationSlideStyles,
            oakModalAnimationZoomStyles,
        ];
    }
    render() {
        return html `${this._isOpen
            ? html `
          <div id=${this.elementId} class=${classMap(this.getClassMap('base'))}>
            <div class=${classMap(this.getClassMap('container'))}>
              <div
                class=${classMap(this.getClassMap('backdrop'))}
                @click=${this._handleClose}
              ></div>
              <div class=${classMap(this.getClassMap('content'))}>
                <div class=${classMap(this.getClassMap('content-container'))}>
                  <div class=${classMap(this.getClassMap('heading'))}>
                    <oak-internal-modal-header
                      heading=${this.heading || ''}
                    ></oak-internal-modal-header>
                  </div>
                  <div class=${classMap(this.getClassMap('body'))}>
                    <slot name="body"></slot>
                    <!-- <oak-internal-modal-body
                      ><slot name="body"></slot
                    ></oak-internal-modal-body> -->
                  </div>
                  <div class=${classMap(this.getClassMap('footer'))}>
                    <slot name="footer"></slot>
                    <!-- <oak-internal-modal-body
                      ><slot name="body"></slot
                    ></oak-internal-modal-body> -->
                  </div>
                  <!-- <oak-internal-modal-footer
                    ><slot name="footer"></slot
                  ></oak-internal-modal-footer> -->
                </div>
              </div>
            </div>
          </div>
        `
            : html ``}`;
    }
};
__decorate([
    property({ type: Boolean })
], OakModal.prototype, "isOpen", void 0);
__decorate([
    property({ type: Boolean })
], OakModal.prototype, "rounded", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "height", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "width", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "animationSpeed", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "animationStyle", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "heading", void 0);
__decorate([
    property({ type: String })
], OakModal.prototype, "color", void 0);
__decorate([
    property({ type: Number })
], OakModal.prototype, "backdropIntensity", void 0);
__decorate([
    property({ type: Number })
], OakModal.prototype, "paddingHorizontal", void 0);
__decorate([
    property({ type: Number })
], OakModal.prototype, "paddingVertical", void 0);
__decorate([
    property({ type: Number })
], OakModal.prototype, "elevation", void 0);
__decorate([
    property({ type: Boolean })
], OakModal.prototype, "_isOpen", void 0);
OakModal = __decorate([
    customElement(customElementName)
], OakModal);
export { OakModal };
//# sourceMappingURL=index.js.map