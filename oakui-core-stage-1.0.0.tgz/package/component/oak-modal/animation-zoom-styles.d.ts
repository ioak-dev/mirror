export declare const oakModalAnimationZoomStyles: import("lit-element").CSSResult;
//# sourceMappingURL=animation-zoom-styles.d.ts.map