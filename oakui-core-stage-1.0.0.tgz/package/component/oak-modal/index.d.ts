import { LitElement } from 'lit-element';
import '../../_internal/component/oak-internal-modal-header';
import '../../_internal/component/oak-internal-modal-body';
import '../../_internal/component/oak-internal-modal-footer';
export declare class OakModal extends LitElement {
    private elementId;
    isOpen: boolean;
    rounded: boolean;
    height?: 'auto' | 'small' | 'medium' | 'large' | 'full';
    width?: 'auto' | 'small' | 'medium' | 'large' | 'full';
    animationSpeed?: 'slow' | 'normal' | 'fast' | 'none';
    animationStyle?: 'opacity' | 'zoom' | 'slide';
    heading?: string | null;
    color?: 'global' | 'container' | 'surface' | 'float' | 'primary' | 'secondary' | 'tertiary' | 'default' | 'danger' | 'warning' | 'success' | 'info' | 'invert';
    backdropIntensity?: 0 | 1 | 2 | 3 | 4 | 5;
    paddingHorizontal?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
    paddingVertical?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
    elevation?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    private _isOpen;
    connectedCallback(): void;
    private init;
    shouldUpdate(_changedProperties: Map<string | number | symbol, unknown>): boolean;
    private _handleClose;
    private propagateEvent;
    private getClassMap;
    static get styles(): (import("lit-element").CSSResult | import("lit-element").CSSResult[])[];
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=index.d.ts.map