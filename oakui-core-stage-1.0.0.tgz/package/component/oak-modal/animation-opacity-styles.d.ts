export declare const oakModalAnimationOpacityStyles: import("lit-element").CSSResult;
//# sourceMappingURL=animation-opacity-styles.d.ts.map