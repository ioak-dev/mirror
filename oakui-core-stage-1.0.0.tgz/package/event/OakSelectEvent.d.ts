export declare const SELECT_FOCUS_EVENT = "select-focus";
export declare const SELECT_CHANGE_EVENT = "select-change";
export declare const SELECT_INPUT_EVENT = "select-input";
export declare const SELECT_ACTION_ITEM_EVENT = "select-action-item";
//# sourceMappingURL=OakSelectEvent.d.ts.map