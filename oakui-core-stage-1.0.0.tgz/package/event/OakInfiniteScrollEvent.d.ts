export declare const INFINITE_SCROLL_CHANGE_EVENT = "infinite-scroll-change";
//# sourceMappingURL=OakInfiniteScrollEvent.d.ts.map