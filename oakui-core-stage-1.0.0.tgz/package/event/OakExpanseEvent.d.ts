export declare const EXPANSE_EXPANDED_EVENT = "expanse-expanded";
export declare const EXPANSE_COLLAPSED_EVENT = "expanse-collapsed";
//# sourceMappingURL=OakExpanseEvent.d.ts.map