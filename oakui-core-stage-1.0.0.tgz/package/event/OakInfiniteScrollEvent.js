export const INFINITE_SCROLL_CHANGE_EVENT = 'infinite-scroll-change';
//# sourceMappingURL=OakInfiniteScrollEvent.js.map