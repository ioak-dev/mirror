export declare const IMAGE_UPLOADED = "input-uploaded";
//# sourceMappingURL=OakImageUploadEvent.d.ts.map