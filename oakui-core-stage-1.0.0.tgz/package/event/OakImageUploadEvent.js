export const IMAGE_UPLOADED = 'input-uploaded';
//# sourceMappingURL=OakImageUploadEvent.js.map