export declare const CLICK_AREA_CLICK_EVENT = "click-area-click";
//# sourceMappingURL=OakClickAreaEvent.d.ts.map